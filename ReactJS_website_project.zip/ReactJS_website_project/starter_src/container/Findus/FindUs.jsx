import React from 'react';

const FindUs = () => (
  <div>
    FindUs
  </div>
);

export default FindUs;
